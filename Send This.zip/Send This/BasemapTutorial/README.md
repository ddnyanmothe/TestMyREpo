BasemapTutorial
===============

A [Basemap tutorial for ReadTheDocs](https://basemaptutorial.readthedocs.org/en/latest/)

You can build it yourself too using [sphinx](http://sphinx-doc.org/)
