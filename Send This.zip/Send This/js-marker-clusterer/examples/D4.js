
<!DOCTYPE html>
<html >
<head>
<title>Show Google Map with Latitude and Longitude </title>

<script type="text/javascript"
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC6v5-2uaq_wusHDktM9ILcqIrlPtnZgEk&sensor=false">
</script>
<script type="text/javascript">
    function initialize() {
        var lat = document.getElementById('txtlat').value;
        var lon = document.getElementById('txtlon').value;

        var myLatlng = new google.maps.LatLng(lat, lon) // This is used to center the map to show our markers
        var mapOptions = {
            center: myLatlng,
            zoom: 6,
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            marker: true
        };
        var map = new google.maps.Map(document.getElementById("mapcanvas"), mapOptions);
        <!--  --!>
        var userPosition=new google.maps.LatLng(lat,lon);
        var WebServicePosition1=new google.maps.LatLng(43,-98);
        var WebServicePosition2=new google.maps.LatLng(58,93);
        var WebServicePosition3=new google.maps.LatLng(-16,26);

        var myTrip1=[userPosition,WebServicePosition1];
        var myTrip2=[userPosition,WebServicePosition2];
        var myTrip3=[userPosition,WebServicePosition3];

        var flightPath1=new google.maps.Polyline({
            path:myTrip1,
            strokeColor:"#00000F",
            strokeOpacity:0.9,
            strokeWeight:3
        });
        var flightPath2=new google.maps.Polyline({
            path:myTrip2,
            strokeColor:"#ff0000",
            strokeOpacity:0.9,
            strokeWeight:3
        }); 

        var flightPath3=new google.maps.Polyline({
            path:myTrip3,
            strokeColor:"#0000FF",
            strokeOpacity:0.9,
            strokeWeight:3
        });


        flightPath1.setMap(map);
        flightPath2.setMap(map);
        flightPath3.setMap(map);

        var marker = new google.maps.Marker({
            position: myLatlng
        });
        marker.setMap(map);
    }
</script>
</head>
<body >

    <form id="form1" runat="server">
        <table >
            <tr>
                <td>Enter Latitude:</td>
                <td><input type="text" id="txtlat" value="40.44390000000001" /> </td>
            </tr>
            <tr>
                <td>Enter Longitude:</td>
                <td><input type="text" id="txtlon" value="-79.9562" /> </td>
            </tr>
            <tr>
                <td></td>
                <td><input type="button" value="Submit" onclick="javascript:initialize()" /> </td>
            </tr>
        </table>
        <div id="mapcanvas" style="width: 500px; height: 400px">


        </div>

    </form>

</body>
</html>