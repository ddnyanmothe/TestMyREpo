from geopy.geocoders import Nominatim
geolocator = Nominatim()
file = open("User_locations.txt",'r')
for input in file:
    read = input.split("	")[1]
    f = open("Lat-long.txt",'a')
    location = geolocator.geocode(read)
    f.write(str(location.latitude)+"\t"+str(location.longitude))
    f.write('\n')